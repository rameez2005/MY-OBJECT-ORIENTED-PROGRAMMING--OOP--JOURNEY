//#include<iostream>
//#include<string>
//
//using namespace std;
//void output();
//class eventcard {
//private :
//	string Event_Name;
//	string Date;
//	string Time;
//	string Venue;
//public :
//	eventcard(string n="", string d="", string t="", string v="") :Event_Name(n), Date(d), Time(t), Venue(v) {};
//	friend void output(eventcard);
//
//};
//
//void output(eventcard obj) {
//	cout << "NAME : " << obj.Event_Name << endl;
//	cout << "DATE : " << obj.Date << endl;
//	cout << "TIME : " << obj.Time << endl;
//	cout << "VENUE : " << obj.Venue << endl;
//
//}
//
//int main() {
//	eventcard obj1("CHRISTMAS", "25 DECEMBER", "9 AM", "MILLAT TOWN");
//	output(obj1);
//	system("pause");
//	return 0;
//}