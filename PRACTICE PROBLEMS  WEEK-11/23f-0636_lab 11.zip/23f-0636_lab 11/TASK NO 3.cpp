//#include<iostream>
//#include<string>
//
//using namespace std;
//
//class factorial {
//	int n;
//	int fact;
//
//public:
//	factorial( int a) :n(a) , fact(a){};
//	void  operator ! () {
//		for (int i = n-1; i > 0; i--) {
//			fact *= i; 
//		}
//		cout << "FACTORIAL IS : " << fact << endl;
//	}
//};
//
//int main() {
//	cout << " ENTER THE NUMBER TO CALCULATE FACTORIAL \n";
//	int n;
//	cin >> n;
//	factorial f(n);
//	!(f);
//	system("pause");
//	return 0;
//}