//#include<iostream>
//#include<string>
//
//using namespace std;
//
//class complex {
//	float a ;
//	float b;
//
//public:
//	complex(float a , float b) :a(a), b(b) {};
//	complex  operator + (complex & c) {
//		return complex(a + c.a, b + c.b);
//		}
//
//	void output() {
//		cout << "THE SUM IS : " << a + b << endl;
//	}
//};
//
//int main() {
//	complex c1(1, 0.5);
//
//	complex c2(2, 0.8);
//	complex c3 = c1 + c2;
//	c3.output();
//	system("pause");
//	return 0;
//}